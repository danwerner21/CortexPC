This ZIP file contains revision B of Pitfall! for the Texas Instruments TI-99/4A Home Computer.

Revision B contains all bug-fixes of revision A and additionaly only needs 256 bytes of scratch-pad memory.
It means you can finally run Pitfall! on a bare console when using one of the new homebrew cartridge boards (PCB revision C!).  
 
Here are the differences between Pitfall! revision A and B:
1) Revision A shows "remake by Retroclouds 2009" on the title screen, revision B shows "remake by retroclouds"
2) Revision A still has some nasty bugs. Revision B has all know bugs removed.
3) Revision A has a hidden key combination for showing its version number, revision B does not.
4) Last but not least, revision A always requires 32K RAM memory expansion even when put on EPROM.  

readme.txt			This file
pitfall.rpk			32K (4x8) bank-switched ROM image packed in RPK archive for using in MESS.
pitfall.bin			32K (4x8) bank-switched ROM image you can use in classic99.
pitfall manual rev B.pdf	Instruction manual
PITFALLB			The disk version of Pitfall! revision B
PITFALLC        		The disk version of Pitfall! revision B
PITFALLD        		The disk version of Pitfall! revision B


Here are the usage conditions:
You may freely use the ROM image in your favourite emulator or burn the ROM image into EPROM for own usage or 
for sharing with friends. However, you may not sell the ROM image/EPROM without my permission.
I've spend over 1000 hours in creating this conversion for the TI-99/4A. Why should you be making some quick money with it?


Enjoy!

retroclouds (02-20-2010)