This file is best viewed using a text editor using a fixed-pitch font.  Ensure word-wrap is on and the window is sized to at least 90 columns.

These are all the disks I could find.  They have been cleaned and tidied up so that they are in new/release condition.  I have added README files where possible and added 'Hello World!' examples to the programming languages.

Valid disk formats used on the Cortex are:

Tracks: 40/80, 16 sectors per track.
Sides: Single or Double.
Density: Single (128 bytes per sector) or Double (256 bytes per sector).

Capacities:

40T,SS,SD = 80K  (40 tracks * 1 side  * 16 sectors * 128 byte per sector)
40T,SS,DD = 160K (40 tracks * 1 side  * 16 sectors * 256 byte per sector)
40T,DS,SD = 160K (40 tracks * 2 sides * 16 sectors * 128 byte per sector) 
40T,DS,DD = 320K (40 tracks * 2 sides * 16 sectors * 256 byte per sector) 
 
80T,SS,SD = 160K (80 tracks * 1 side  * 16 sectors * 128 byte per sector)
80T,SS,DD = 320K (80 tracks * 1 side  * 16 sectors * 256 byte per sector)
80T,DS,SD = 320K (80 tracks * 2 sides * 16 sectors * 128 byte per sector) 
80T,DS,DD = 640K (80 tracks * 2 sides * 16 sectors * 256 byte per sector) 

The files are byte-for-byte binary images of actual floppy disks.  There are a few additional bytes tagged on the end so that the Emulator knows their original physical attributes (number of tracks, sides, density etc.).  They all work directly with the Emulator.  Additionally, if you have a working Cortex with the TMS9909 Disk Interface, you can use the PC Comms Utility to recreate physical disks.  See the notes that come with the Utility on how to do this.

Experimentation is the best way to learn and there's no risk of destroying the originals!  However, here is a brief description of the images and some useful notes:

Where the image name contains 40 or 80, this indicates that it is a bootable disk that is expecting either the TMS9928/9 (40 column mode only) or the MSX V9938 (80 column mode).  The Emulator supports the V9938 80 column mode, so the 80 column versions (especially for MDEX that natively expects an 80 column 'VDU') can be used.

Cortex Basic includes a BOOT command.  This reads the first sector on the disk that contains the boot parameters and then loads the disk accordingly.  This is how CDOS is loaded.  However, MDEX was designed to run on the Marinchip M9900 which used a different bootloader and disk structure.  When MDEX was ported to the Cortex by Micro Processor Engineering, they came up with a two-staged approach.  Firstly, an MDEX Bootloader disk is placed in Drive 0 and loaded with the BOOT command.  The disk is then changed to the normal MDEX System Disk and loaded by the Bootloader.  The MDEX Bootloader Disk became obsolete when the bootloader itself was converted to be an executable program on CDOS.  Thus, MDEX was loaded from CDOS which made things slightly easier since only two disks needed to be exchanged rather than three...    


CDOS
----

This was the preferred Disk Operating System as it simply extended Cortex Basic with a Disk Filing System, whereas MDEX was a complete Operating System that replaced Cortex Basic.  In it's simplest form it added the ability to save and load Basic/Machine Code programs and provided sequential/random access files for data storage.  The disk came with a few fundamental utilities for viewing the directory, file deletion, copying and disk formatting.

As time went by, the CDOS Utilities were modified and additional ones developed.  Chris Young was a very prolific contributor to the User Group and he was instrumental in the transformation of Cortex Basic/CDOS to a full development system.  He added the V9938 extensions to Cortex Basic to provide 80x26 text and also many of the additional graphics modes.  He also developed an editor (SED) and assembler (ASM) so that assembly language programs could very easily be developed.   

Here are some notes on the disks:

CDOS 1.20 Master Release.dsk

The original disk...

CDOS40 Release.dsk
CDOS80 Release.dsk

This is an extended CDOS with just about everything you'll need.  It has the aforementioned editor/assembler, V9938 extensions (CDOS80), MDEX Bootloader, MDEX Transfer (transfers executables developed on MDEX to CDOS) and a simple Hello World example.

CDOS Chris Youngs Utils Release.dsk

The disk that Chris' utils was supplied on.

CDOS SED & ASM Source Release.dsk
CDOS V9938 Source Release.dsk

Contains the source code for SED, ASM & V9938.  One day me or someone else can modify SED & ASM to use 80 column mode...

CDOS 2.00 (TMS2797) Release.dsk

This is the updated CDOS for the replacement TMS2797 Disk Controller.  Not been tested as I didn't have the new board.

CDOS40+Recovery Utils Release.dsk

Contains utilities (DISKIMG, SAFORMAT, DSEND, CASS232) that complement the PC Comms Utility to enable the disk images to be recreated using a PC connected to a Cortex via RS232. 


MDEX
----

MDEX was released before CDOS and therefore was the initial option to use disks with the Cortex.  This presented a problem as it was completely incompatible with Cortex Basic.  In addition, disk access was excruciating slow, the display was expecting an 80 column VDU which didn't look very good on the 40 column TMS9928/9 and there were no graphics or use of Cortex-specific hardware!  However, those that stuck with it discovered a very powerful (for its time) Operating System that had a fantastic assembler and some good programming languages.  Even after CDOS was released, it wasn't uncommon to develop utilities on MDEX and then transfer them to the CDOS environment.  The V9938 video card allowed MDEX to return to its 80 column mode and all was right with the World!

As mentioned above, MDEX needs a special bootloader to get it running.  Initially this was accomplished using a special MDEX Bootloader Disk (developed by MPE).  The bootloader was converted to be run as a CDOS program, so the preferred method is to use the LOAD 0,"MDEX" command (or just *MDEX if it's on Drive 0).  There were two bootloaders, one for single and one for double-sided MDEX System Disks.  The version that comes with CDOS has been modified to prompt for number of sides prior to loading MDEX.

Disks:

MDEX40 System Release.dsk
MDEX80 System Release.dsk

These are the 40 or 80 column MDEX System Disks.  They contain the MDEX core system plus an assembler/linker and a full-screen editor (CWIN), which is a Cortex-specific version of MDEX Window.  

MDEX40 Sysgen Release.dsk
MDEX80 Sysgen Release.dsk

The MDEX System Generation Kit.  Use this to modify or create special drivers for MDEX.  The README file on the disk gives more specific information.

MDEX40 QBASIC Release.dsk
MDEX80 QBASIC Release.dsk

The QBASIC compiler.  Programs can be split over several modules and mixed with assembly language.  A Hello World example is given.  See the README file ('type readme' or 'cwin readme').

MDEX40 SPL Release.dsk
MDEX80 SPL Release.dsk

The SPL (Systems Programming Language) compiler.  This is the closest thing MDEX has to C.  Lots of fun.  Programs can be split over several modules and mixed with assembly language.  A Hello World example is given.  See the README file ('type readme' or 'cwin readme').

MDEX40 FORTH Release.dsk
MDEX80 FORTH Release.dsk

The MPE FORTH compiler.  A Hello World example is given.  See the README file ('type readme' or 'cwin readme').

MDEX40 Pascal Release.dsk
MDEX80 Pascal Release.dsk

The Pascal compiler.  A Hello World example is given.  See the README file ('type readme' or 'cwin readme').

MDEX40 Basic Games Release.dsk
MDEX80 Basic Games Release.dsk

A couple of games for MDEX Basic interpreter (not QBASIC).

MDEX Window Screen Editor Release.dsk

The source code for MDEX Window full-screen editor.  See the README file for more info.

MDEX Tony Rowell Utils Release.dsk

Tony was one of the creators of the Cortex.  Here he has provided some useful MDEX utilities, including an exceptional disassembler.

MDEX MPE CAT Source Release.dsk
MDEX MPE Format Source Release.dsk

These contain the source code for the MPE-developed CAT and FORMAT utilities.  CAT provides a 40 column directory listing. FORMAT is a Cortex-specific disk format utility.

MDEX Boot Loader Single Density.dsk
MDEX Boot Loader Double Density.dsk
MDEX Boot Loader Source Release.dsk

These are the original MDEX Bootloader disks, along with the source code.













 

 





 

  

