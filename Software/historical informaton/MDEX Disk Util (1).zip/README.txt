The MDEX Disk Utility is a program I developed to extract text and executable files from MDEX Disk Images.  Using the Emulator, I developed the SAFORMAT and DISKIMG programs (used by the PC Comms Utility to recreate disks).  Once the programs were ready, I used the MDEX Disk Utility to extract the files to the PC environment so that they can be downloaded to the Cortex as cassette images using the PC Comms Utility.  In a way, this complements the MDEXXFER program on the CDOS disks which transfers MDEX programs to the CDOS environment.

Probably not much use on a daily basis, but included anyway...

