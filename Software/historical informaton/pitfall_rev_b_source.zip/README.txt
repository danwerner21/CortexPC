This ZIP file contains the source code for revision B of Pitfall! for the Texas Instruments TI-99/4A Home Computer.

It contains the source code for both the disk and cartridge version.

Revision B contains all bug-fixes of revision A and additionaly only needs 256 bytes of scratch-pad memory.
It means you can finally run Pitfall! on a bare console when using one of the new homebrew cartridge boards (PCB revision C!).  
 

readme.txt			This file
how to assemble pitfall.pdf	Assembly instructions
/tms9900/*			The source code files and some utilities

Here are the usage conditions:
You may use the source code for learning assembly language or for trying out different hacks.
You may assemble the source code and use the generated ROM image in your favourite emulator 
or burn the ROM image into EPROM for own usage or for sharing with friends. 
However, you may not sell the source code or assembled ROM image/EPROM without my permission.

I've spend over 1000 hours in creating this conversion for the TI-99/4A. Why should you be making some quick money with it?


Enjoy!

retroclouds (02-20-2010)