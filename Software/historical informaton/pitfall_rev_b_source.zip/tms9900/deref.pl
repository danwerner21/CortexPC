#!/usr/bin/perl
#########################################################################################
# winasm99 post-processor v0.1                                                          #
# (c)2010 by retroclouds (http://www.retroclouds.de)                                    #
#########################################################################################
# 07.01.2010     rc        Initial version created                                      #
#########################################################################################
  use strict;
  use File::Basename;
  use Getopt::Long qw (:config bundling auto_abbrev);
  our %st          = ();
  our @symfiles    = ();
  our $ok          = 0;
  our $ver         = 'v0.1';
  
  Getopt::Long::Configure qw (bundling_override);
  our $opt = GetOptions(  "help|h"        => sub { },
                          "bank0|b0=s"    => sub { $ok=1; read_listing(0, @_[1]) },
                          "bank1|b1=s"    => sub { $ok=1; read_listing(1, @_[1]) },
                          "bank2|b2=s"    => sub { $ok=1; read_listing(2, @_[1]) },
                          "bank3|b3=s"    => sub { $ok=1; read_listing(3, @_[1]) },
                          "bank4|b4=s"    => sub { $ok=1; read_listing(4, @_[1]) },
                          "bank5|b5=s"    => sub { $ok=1; read_listing(5, @_[1]) },
                          "bank6|b6=s"    => sub { $ok=1; read_listing(6, @_[1]) },
                          "bank7|b7=s"    => sub { $ok=1; read_listing(7, @_[1]) },
                          "bank8|b8=s"    => sub { $ok=1; read_listing(8, @_[1]) },
                          "bank9|b9=s"    => sub { $ok=1; read_listing(9, @_[1]) },
                          "bank10|b10=s"  => sub { $ok=1; read_listing(10,@_[1]) },
                          "bank11|b11=s"  => sub { $ok=1; read_listing(11,@_[1]) },
                          "bank12|b12=s"  => sub { $ok=1; read_listing(12,@_[1]) },
                          "bank13|b13=s"  => sub { $ok=1; read_listing(13,@_[1]) },
                          "bank14|b14=s"  => sub { $ok=1; read_listing(14,@_[1]) },
                          "bank15|b15=s"  => sub { $ok=1; read_listing(15,@_[1]) },
                          "sym|file|f=s"  => \@symfiles );
     
  process_template(@symfiles) if (scalar(@symfiles) > 0);
  usage()                     if (!$ok);
  exit;

  
  sub read_listing {
      my $check  = 0;
      while (@_) {
           my $bank     = shift;
           my $filename = shift;
           my $pc       = 0;
           my $oldpc    = 0;
           my $check    = 0;                      
           my (undef, undef, $suffix) = fileparse($filename,qr{\..*});
           $filename .= ".lst" unless ($suffix);
           print "\n  BANK $bank -- Reading LST file \"$filename\" \n";
           if (-e "$filename") {
              open(HND, $filename) or die("Could not open \"$filename\"\n");
              print "  +-------------------------------------------------+\n";
              print "  | PC    | OLD PC | BYTES | Remark                 |\n";
              while(<HND>) {
                  chomp;                          ## No newline
                  s/^;.*//;                       ## No comments
                  s/\s+/_/g;                      ## Replace whitespace with single _            
                  $check = 1  if ($_ =~ /^_------_Symbol_Listing_/);
                  if ($check == 1) {
                     my $line = $_;
                     if ($line =~ /_ABS:/) {
                        my $label = substr($line,1,index($line,"_",1) -1);
                        my $addr  = substr($line,index($line,"ABS:")+4,4);
                        $st{"B$bank|$label"} = ">$addr";
                     }
                  } else {
                     my @word = split(/\_/,substr($_,1));
                     $pc = hex ($word[1]) if (($word[1] =~ /[0-9|A-F]{4}/) && ($word[1] ne "0000"));
                     if ($pc < $oldpc) {
                         printf("  | >%X | >%X  | %5d | Overlapping segment |\n", $pc, $oldpc, $pc - $oldpc);
                     } elsif (($pc > $oldpc + 2) && ($oldpc > 0)) {
                         printf("  | >%X | >%X  | %5d | Free space >%X->%X |\n", $pc, $oldpc, $pc - $oldpc,$oldpc + 2, $pc - 1);
                     }
                     $oldpc = $pc;                     
                  }                  
              }
              print "  +-------------------------------------------------+\n";
           } else {
             print "  ERROR: Could not read LST file!\n";
           } 
      }
  }

  
  sub process_template {
      while (my $filename = shift) {
         my (undef, undef, $suffix) = fileparse($filename,qr{\..*});
         $filename .= ".sym" unless ($suffix);
         my $fileout  = $filename;
         $fileout     =~ s/\.sym$/\.a99/;
         if (-e "$filename") {
            open(HND, $filename)   or die("Could not open \"$filename\"\n");
            open(OUT, ">$fileout") or die("Could not open \"$fileout\"\n");
            print "\n  Processing template file \"$filename\" \n";
            print "  Creating assembly source \"$fileout\" \n";            
            print OUT "* Generated by \"$0\" $ver using template $filename\n";
            print OUT "* ", scalar (localtime), "\n";
            print "  ";
            while(<HND>) {         
               my $line = $_;
               if ($line =~ /\<(.*)\>/) {           
                  my $addr = $st{$1} ? $st{$1} : "!ERROR!";
                  $addr .= ' ' x (length($1) - length($addr) + 2);               
                  $line =~ s/\<.*\>/$addr/;
               }            
               print ".";
               print OUT $line;    
            }
            print "\n";
            close(OUT) or die("Could not close \$fileout\"\n");
         } else {
             print "  ERROR: Could not read symbol template!\n";
         }
     }
  }
  
  
  
  sub usage {
   print qq{\nUsage: $0 [OPTION]...\n
       winasm99 post-processor $ver
       (c)2010 by retroclouds (http://www.retroclouds.de)
       
       --sym|file|f=filename\tSymbol template file to process

         The template file is searched in the current directory 
         if no path is given. The file extension ".sym" will be 
         assumed if no extension is provided.

         The script will automatically create a file with extension ".a99"
         having all bank references replaced by the corresponding addresses.
         
       --help|h\t\t\tDisplay this help and exit

       --bank0|b0=value\t\tListing file for bank 0
       --bank1|b1=value\t\tListing file for bank 1
       ...
       --bank15|b15=value\tListing file for bank 15

         The listing file is searched in the current directory 
         if no path is given. The file extension ".lst" will be 
         assumed if no extension is provided.
       
       
       EXAMPLES
          deref.pl -b0=ROMC -b1=ROMD -b2=ROME -b3=ROMF -f=bank_template
          deref.pl -b0=ROMC.lst -b1=ROMD.lst -f=abc.sym -f=def.sym -f=abc2.sym
       
       
       FORMAT for bank reference tags in template files
          <B(0-15)|label>
       
          EXAMPLES
            ZLOGO   EQU   <B0|ZLOGO>     ; Address of ZLOGO  in BANK0
            DRAWB   EQU   <B1|DRAWB>     ; Address of DRAWB  in BANK1       
     };
   exit;
 }